#include "MySet.h"
MySet::MySet() {

}

void MySet::addItem(int item) {
	if (!isItemOf(item)) items.push_back(item);
};

void MySet::removeItem(int item) {
	items.erase(items.begin() + findItem(item));
};

void MySet::printItem() {
	for (int i = 0; i < items.size(); ++i) {
		cout << items[i] << " ";
	}
	cout << endl;
};

int MySet::findItem(int item) {
	for (int i = 0; i < items.size(); ++i) {
		if (items[i] == item) return i;
	}
	return -1;
};

bool MySet::isItemOf(int checkedItem) {
	if (findItem(checkedItem) >= 0) return true;
	return false;
};

bool MySet::isSubset(MySet set2) {
	if (items.size() > set2.size()) return false;

	for (int i = 0; i < items.size(); ++i) {
		if (!set2.isItemOf(items[i])) return false;
	}
	return true;
};

int MySet::size() {
	return items.size();
};