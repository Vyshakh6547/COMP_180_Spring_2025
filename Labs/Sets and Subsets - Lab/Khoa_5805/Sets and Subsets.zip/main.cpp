/*
Thai Dang Khoa Tran
COMP 180
Propositional Logic Lab
*/
#include <iostream>
#include "MySet.h"
using namespace std;

int main() {
	MySet set1, set2;
	int	setInput;
	int	chkInput1;
	int	chkInput2;

	cout << "Input set 1: ";

	do
	{

		cin >> chkInput1;

		if (cin) set1.addItem(chkInput1);

	} while (cin);

	cin.clear();
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	cout << "Input set 2: ";

	do
	{

		cin >> chkInput2;

		if (cin) set2.addItem(chkInput2);

	} while (cin);

	cout << "Set1: ";
	set1.printItem();
	cout << "Set1 size : " << set1.size() << endl;
	cout << "Set2: ";
	set2.printItem();
	cout << "Set2 size : " << set2.size() << endl;

	cout << "Remove item 5 of set1" << endl;
	set1.removeItem(5);

	cout << "Set1: ";
	set1.printItem();
	cout << "Set1 size after remove : " << set1.size() << endl;

	if(set1.isSubset(set2)) cout << "Set1 is subset of set2" << endl;
	else cout << "Set1 is not subset of set2" << endl;

	return 0;
}