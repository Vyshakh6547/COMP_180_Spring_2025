#pragma once
#include <vector>

#include <iostream>

using namespace std;

class MySet
{
private:
	vector<int> items;
public:
	MySet();
	void addItem(int);
	void removeItem(int);
	int findItem(int);
	void printItem();
	bool isItemOf(int);
	bool isSubset(MySet);
	int size();
};

