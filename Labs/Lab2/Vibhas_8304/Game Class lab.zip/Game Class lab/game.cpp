#include <iostream>
#include "game.h"

game::game() {
    rows = 0;
    cols = 0;
    playerRow = 0;
    playerCol = 0;
    world = nullptr;
}

game::~game() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            delete world[i][j];
        }
        delete[] world[i];
    }
    delete[] world;
}

void game::setUpGame() {
    rows = 6;
    cols = 6;

    world = new Location * *[rows];
    for (int i = 0; i < rows; i++) {
        world[i] = new Location * [cols];
        for (int j = 0; j < cols; j++) {
            world[i][j] = new Location();
        }
    }

    world[0][2] = new Crystal;
    world[1][3] = new Crystal;
    world[2][3] = new Crystal;
}

void game::drawGame() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (i == playerRow && j == playerCol) {
                cout << "P";
            }
            else {
                world[i][j]->draw();
                cout << "";
            }
        }
        cout << endl;
    }
}

void game::playGame() {
    setUpGame();
    world[playerRow][playerCol]->visit(p);
    drawGame();
    char input;
    do {
        cout << "choose your direction-> W,A,S,D,E ";
        cin >> input;

        switch (input) {
        case 'W':
            if (playerRow > 0) playerRow--;
            break;
        case 'A':
            if (playerCol > 0) playerCol--;
            break;
        case 'S':
            if (playerRow < rows - 1) playerRow++;
            break;
        case 'D':
            if (playerCol < cols - 1) playerCol++;
            break;
        }
        world[playerRow][playerCol]->visit(p);
        drawGame();
    } while (input != 'E');
}