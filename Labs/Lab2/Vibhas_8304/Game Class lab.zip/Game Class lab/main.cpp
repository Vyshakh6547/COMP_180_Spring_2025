#include "player.h"
#include "crystal.h"
#include "location.h"
#include "game.h"
#include <iostream>

using namespace std;

int main() {
	Player p;
	Location location;
	Crystal crystal;
	game g;

	g.playGame();


	return 0;




}
