#pragma once
#include <iostream>
#include <vector>
using namespace std;
class Player
{
private:
	string name;
	int age;
public:
	Player();
	Player(string, int);
	void SetName(string);
	void SetAge(int);
	string GetName();
	int GetAge();
	void PrintInfo();
};