#include "player.h"
#include "crystal.h"
#include "location.h"
#include <iostream>

using namespace std;

int main() {
	Player p;
	Location location;
	Crystal crystal;

	cout << "Drawing initial states: " << endl;
	location.draw();
	cout << endl << "Visiting each location: " << endl;
	location.visit(p);
	crystal.visit(p);
	cout << endl << "Redrawing Locations:" << endl;
	location.draw();
	crystal.draw();

	return 0;




}
