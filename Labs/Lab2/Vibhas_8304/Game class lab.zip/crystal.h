#pragma once
#include "location.h"
class Crystal :public Location
{
private:
	bool taken;
public:
	int visit(Player& p);
	void draw();
	Crystal();

};

