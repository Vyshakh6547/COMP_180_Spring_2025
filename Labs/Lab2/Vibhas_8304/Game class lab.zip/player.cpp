#include "Player.h"
Player::Player() {
	name = " ";
	age = 0;
}
Player::Player(string n, int a) {
	name = n;
	age = a;
}
void Player::SetName(string n) {
	name = n;
}
void Player::SetAge(int a) {
	age = a;
}

string Player::GetName() {
	return name;
}
int Player::GetAge() {
	return age;
}
void Player::PrintInfo() {
	cout << "PlayerName: " << name << "  PlayerAge: " << age << endl;
}