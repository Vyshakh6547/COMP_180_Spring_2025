#include "game.h"

game::game() {
	rows = 0;
	cols = 0;
	playerRow = 0;
	playerCol = 0;


}

void game::setUpGame() {
	rows = 6;
	cols = 6;
	world = new Location * *[rows];
	for (int i = 0; i < rows; i++) {
		world[i] = new Location * [cols];
		for (int j = 0; j < cols; j++) {
			world[j] = new Location * [cols];

		}
		cout << "**" << endl;

	}
}

void game::drawGame() {

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			if (i == playerRow && j == playerCol) cout << 'P' << endl;
			else world[i][j]->draw();

		}

	}
}
void game::playGame() {
	while
}


