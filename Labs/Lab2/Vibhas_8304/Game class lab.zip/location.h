#pragma once

#include "Player.h"

class Location
{
protected:
	char symbol;
	bool visited;
public:
	Location(char s = ' ');
	int visit(Player& p);
	virtual void draw();


};

