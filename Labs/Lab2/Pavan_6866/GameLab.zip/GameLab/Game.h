#pragma once
#include "Player.h"
#include "Location.h"
#include "Crystal.h"
class Game
{
protected:
	int rows;
	int cols;
	int playerRow;
	int playerCol;
public:
	Game();
	Game(int, int, int, int);
	Location ***world;
	Crystal crystal;
	Player p;
	void setUpGame(int row,int col, int pr, int pc);
	void drawGame();
	void playGame(int pr,int pc);
};

