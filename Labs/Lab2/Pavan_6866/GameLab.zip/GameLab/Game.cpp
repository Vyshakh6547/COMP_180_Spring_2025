#include "Game.h"
#include "Location.h"
#include "Player.h"
#include "Crystal.h"
Game::Game() {
	 rows=0;
	 cols=0;
	 playerRow=0;
	 playerCol=0;
}
void Game::setUpGame(int r,int c, int pr, int pc) {
	rows = r;
	cols = c;
	world = new Location **[rows];
	for (int i = 0; i < rows; i++) {
		world[i] = new Location *[cols];
		for (int j = 0; j < cols; j++) {
			world[i][j] = new Location();
		}
	}
	world[1][2] = new Crystal();
	world[3][3] = new Crystal();
	world[6][6] = new Crystal();
}

void Game::drawGame() {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			if (i == playerRow && j == playerCol) cout<<'P';
			else world[i][j]->draw();
		}
		cout << endl;
	}
}

void Game::playGame(int pr,int pc) {
	setUpGame(8,8,pr,pc);
	playerRow = pr;
	playerCol = pc;
	world[playerRow][playerCol]->visit(p);
	drawGame();
	char input;
	do {
		cout << "What direction would you like to go" << endl;
		cin >> input;
		switch (input) {
		case 'w':
			playerRow--;
			break;
		case 'a':
			playerCol--;
			break;
		case 's':
			playerRow++;
			break;
		case 'd':
			playerCol++;
			break;
		}
		if (playerRow == 1 && playerCol == 2) {
			world[playerRow][playerCol]->visit(p);
		}
		else if (playerRow == 3 && playerCol == 3) {
			world[playerRow][playerCol]->visit(p);
		}
		else if (playerRow == 6 && playerCol == 6) {
			world[playerRow][playerCol]->visit(p);
		}
		world[playerRow][playerCol]->visit(p);
		drawGame();
	} while (input != 'q');
}