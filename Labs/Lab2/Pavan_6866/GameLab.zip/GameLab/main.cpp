#include "Location.h"
#include "Crystal.h"
#include "Player.h"
#include "Game.h"
#include <iostream>
using namespace std;
int main() {
	int pr, pc;
	cout << "Please give the starting row of the player" << endl;
	cin >> pr;
	cout << "Please give the starting column of the player" << endl;
	cin >> pc;
	Player p;
	Location loc;
	Crystal crystal;
	Game g;
	g.playGame(pr,pc);
	return 0;

}