#pragma once
#include <iostream>
#include <vector>
using namespace std;
class Player
{
private:
	string playerName;
	int playerAge;
	string group;
public:
	Player();
	Player(string, int);
	void SetplayerName(string);
	void SetplayerAge(int);
	string Getplayername();
	int GetplayerAge();
	void PrintInfo();
	void Setgroup(string);
	string Getgroup();
};


