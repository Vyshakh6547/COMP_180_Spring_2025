//
//  Game.cpp
//  Game_Class_Lab
//
//  Created by Darshana Patil on 2/11/25.
//

#include "Game.hpp"
//#include "Game.h"
#include "Crystal.hpp"
#include "Location.hpp"

Game::Game()
{
    rows = 0;
    cols = 0;
    playerRow = 0;
    playerCol = 0;
}

void Game::setUpGame(int r, int c, int prow, int pcol)
{
    playerCol= pcol;
    playerRow=prow;
    world =  new Location **[rows];
    
    rows= r;
    cols=c;
    for (int i = 0; i < rows; i++)
    {
        world[i] = new Location * [cols];

        for (int j = 0; j < cols; j++)
        {
            world[i][j] = new Location();

        }
    }

    world[1][1] = new Crystal();
    world[3][2] = new Crystal();
    world[4][4] = new Crystal();

}

void Game::drawGamw()
{
        for (int i = 0; i < rows; i++)
    {
        for (int j=0; j < cols; j++)
        {
            if (i == playerRow && j == playerCol)
            {
                cout << "P";
            }
            else
            {
                world[i][j]->draw();
            }
        }
        cout<< endl;
    }
    
}

void Game::playGame(int prow, int pcol)
{
    playerCol= pcol;
    playerRow=prow;
    char choice = ' ';
    
    setUpGame(8, 8, prow, pcol);
    
    playerCol= pcol;
    playerRow=prow;
    
    //world[playerRow][playerCol]->visit(p);
    drawGamw();
    

    do
    {
       // drawGamw();

        cout << "where you want to move (u, d. l, r, q) ?" << endl;
        cin >> choice;

        switch (choice)
        {
        case 'u' :
            if (playerRow > 0 )
            {
                playerRow--;
                world[playerRow][playerCol]->visit(p);
            }

            break;

        case 'd' :

                if (playerRow < rows-1)
            {
                playerRow++;
                world[playerRow][playerCol]->visit(p);
            }
                
            break;

        case 'l':
                if (playerCol >0)
                    playerCol--;
                world[playerRow][playerCol]->visit(p);

            break;

        case 'r':
                if (playerCol < cols-1)
                    playerCol++;
                world[playerRow][playerCol]->visit(p);
        default:
            break;
        }
        
//        if(playerRow==1 && playerCol==2)
//        {
//            world[playerRow][playerCol]-> visit(p);
//        }
//        else if (playerRow==3 && playerCol==2)
//        {
//            world[playerRow][playerCol]->visit(p);
//        }
//        else if (playerRow ==4 && playerCol==4)
//        {
//            world[playerRow][playerCol]->visit(p);
//        }
       world[playerRow][playerCol]->visit(p);
        drawGamw();


    }while(choice != 'q');

}
