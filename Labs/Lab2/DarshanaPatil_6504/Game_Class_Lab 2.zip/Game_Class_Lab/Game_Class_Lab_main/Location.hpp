#pragma once
#include "Player.hpp"

class Location
{

protected:
    bool visited;
    char symbol;

public:
    /*void setVisited();
    void setSymbol();

    bool getVisitedFlag();*/

    Location(char s = ' ');

    void draw();
    int visit(Player& p);
};

