
#pragma once
#include <iostream>

using namespace std;

class Player
{

private:
    string name;
    int age;
    bool foundLetter;

public:
    Player();
    Player(string, int, bool); //parameterized constructor

    void SetName(string);
    void SetAge(int);
    void FindLetter(bool);
    void PrintInfo();

    string GetName();
    int GetAge();


};
