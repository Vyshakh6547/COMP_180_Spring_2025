#pragma once
#include "Location.hpp"
#include "Crystal.hpp"
#include "Player.hpp"

class Game : public Location
{

private:
    Location*** world;
    Crystal c;
    Player p;
    int rows;
    int cols;
    int playerRow;
    int playerCol;



public:
    Game();
    //~Game();//Destructor use to free up the memory
    void setUpGame(int row, int col, int prow, int pcol);
    void drawGamw();

    void playGame(int prow, int pcol);
};

