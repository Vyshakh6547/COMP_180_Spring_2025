#pragma once
#include "Location.hpp"

class Crystal : public Location
{
private:
    bool taken;

public:

    Crystal();

    void draw();
    int visit(Player& p);


};

