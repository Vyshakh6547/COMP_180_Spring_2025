

#include "Player.hpp"

Player::Player()
{
    name = "Darshana";
    age = 21;
    foundLetter = false;
}

Player::Player(string n, int a, bool fl)
{
    name = n;
    age = a;
    foundLetter = fl;
}

void Player::SetName(string n)
{
    name = n;
}

void Player::SetAge(int a)
{
    age = a;
}

string Player::GetName()
{
    return name;
}

int Player::GetAge()
{
    return age;
}

void Player::FindLetter(bool fl)
{
    foundLetter = fl;
}

void Player::PrintInfo()
{
    cout << "Name : " << name << endl;
    cout << "Age: " << age << endl;
}



