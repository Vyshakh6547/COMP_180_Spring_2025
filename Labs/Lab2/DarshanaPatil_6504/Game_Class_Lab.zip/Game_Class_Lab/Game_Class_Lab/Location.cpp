//
//  Location.cpp
//  Game_Class_Lab
//
//  Created by Darshana Patil on 2/11/25.
//

#include "Location.hpp"
//#include "Location.h"
#include <iostream>
using namespace std;

Location::Location(char s)
{
    visited = false;
    symbol=s;
}

void Location::draw()
{
    if (visited) cout << symbol;

    else cout << ".";
}

int Location::visit(Player& p)
{
    visited = true;
    //cout << "You found a magic crystal. ";
    return 1;
}
