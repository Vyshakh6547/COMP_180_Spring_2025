
#include "Player.hpp"
#include "Location.hpp"
#include "Crystal.hpp"
#include "Game.hpp"

#include<iostream>
using namespace std;

int main()
{
    Location lc;
    Player p;
    Crystal c;
    Game game;

//    cout << "Enter the initial location " << endl;
//    lc.draw();
//    c.draw();
//
//    cout << " enter visited location" << endl;
//    lc.visit(p);
//    c.visit(p);
//
//    cout << " redrawing location" << endl;
//    lc.draw();
//    c.draw();

    int spr, spc;
    cout<<"Enter the starting position -"<<endl;
    cin>>spr;
    cout<<"Enter the starting of column - "<<endl;
    cin>>spc;
    
    game.playGame(spr, spc);

    return 0;
}
