//
//  Crystal.cpp
//  Game_Class_Lab
//
//  Created by Darshana Patil on 2/11/25.
//

#include "Crystal.hpp"
//#include "Crystal.h"
#include<iostream>

using namespace std;

Crystal::Crystal() :Location('$')
{
    taken = false;
}

void Crystal::draw()
{
    if (taken)
    {
        cout << " ";
    }

    else Location::draw();
}


int Crystal::visit(Player& p)
{
    return Location:: visit(p);
}
