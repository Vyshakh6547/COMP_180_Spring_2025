#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

bool Conjunction(bool a, bool b) {
    return a && b;
}

bool Disjunction(bool a, bool b) {
    return a || b;
}

bool Negation(bool a) {
    return !a;
}

bool Exclusive(bool a, bool b) {
    return Disjunction(Conjunction(Negation(a), b), Conjunction(a, Negation(b)));
}

bool Implication(bool a, bool b) {
    return Disjunction(Negation(a), b);
}

bool BiConditional(bool a, bool b) {
    return Negation(Exclusive(a, b));
}

void generateTruthTable(const string& input, const vector<char>& variables) {
    int numVars = variables.size();
    int combinations = (1 << numVars);

    for (char var : variables) {
        cout << var << "   ";
    }
    

    for (int i = 0; i < combinations; ++i) {
        map<char, bool> assignment;

        for (int j = 0; j < numVars; ++j) {
            assignment[variables[j]] = (i & (1 << (numVars - j - 1))) != 0;
        }

        bool result = false;
        char var1 = input[0];
        char var2 = input[2];

        if (input[1] == '^') {
            result = Conjunction(assignment[var1], assignment[var2]);
        }
        else if (input[1] == 'v') {
            result = Disjunction(assignment[var1], assignment[var2]);
        }
        else if (input[1] == '~') {
            result = Negation(assignment[var1]);
        }
        else if (input[1] == 'x') {
            result = Exclusive(assignment[var1], assignment[var2]);
        }
        else if (input[1] == '-') {
            result = Implication(assignment[var1], assignment[var2]);
        }
        else if (input[1] == '<') {
            result = BiConditional(assignment[var1], assignment[var2]);
        }

        for (char var : variables) {
            cout << assignment[var] << "   ";
        }
        cout << result << endl;
    }
}

int main() {
    string input;
    cout << "Enter the expression : ";
    getline(cin, input);

    vector<char> variables;
    for (char c : input) {
        if (isalpha(c) && find(variables.begin(), variables.end(), c) == variables.end()) {
            variables.push_back(c);
        }
    }

    generateTruthTable(input, variables);

    return 0;
}
