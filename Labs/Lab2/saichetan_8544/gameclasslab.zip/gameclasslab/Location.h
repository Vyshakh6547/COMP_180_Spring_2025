#pragma once
#include "Player.h"
class Location
{
protected:
	char symbol;
	bool visited;
public:
	Location(char s = 'V');
	int visit(Player& p);
	
	void draw();
};

