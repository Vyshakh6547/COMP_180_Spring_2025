#pragma once
#include "Location.h"
class Lighthouse :
    public Location
{
private:
    bool isOpen;
    int numOfLock;
public:
    Lighthouse();
    void draw();
    void Escape(Player);
    int visit(Player&);
};

