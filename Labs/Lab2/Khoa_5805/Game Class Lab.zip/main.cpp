/*
Thai Dang Khoa Tran
COMP 180
Game Class Lab
*/
#include <iostream>
#include "Player.h"
#include "Game.h"


using namespace std;


int main() {
	Game game;
	Player p;

	game.playGame(p);

	return 0;
}