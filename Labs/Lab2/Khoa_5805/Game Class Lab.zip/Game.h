#pragma once
#include "Location.h"
class Game
{
private:
	Location*** world;
	Player p;
	int rows;
	int cols;
	int playerRow;
	int playerCol;
public:
	Game();
	void setUpGame();
	void drawGame();
	void playGame(Player);
	~Game();
};

