#include "Key.h"
#include <iostream>
using namespace std;

Key::Key() :Location('#')
{
	numOfKey = 3;
	visited = false;
}

void Key::draw() {
	if (numOfKey == 0) cout << " ";
	else Location::draw();
}

int Key::visit(Player& p)
{
	if (visited == false) {
		visited = true;
		cout << "You found " << numOfKey << "keys." << endl;
		return 1;
	}
	return 0;
}