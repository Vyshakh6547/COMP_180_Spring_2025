#include "Crystal.h"
#include <iostream>
using namespace std;

Crystal::Crystal() :Location('$') //passes the parameter �$� to the base
{ //class constructor (in this case, Location)
	taken = false; //initialize class specific attributes here
	visited = false;
}

void Crystal::draw() {
	if (taken) cout << " ";
	else Location::draw();
}

int Crystal::visit(Player& p)
{
	if (visited == false) {
		visited = true;
		cout << "You found a magic crystal." << endl;
		return 1;
	}
	return 0;
}

