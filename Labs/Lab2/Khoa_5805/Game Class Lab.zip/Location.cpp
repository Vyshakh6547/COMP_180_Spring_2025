#include "Location.h"

Location::Location() {
	symbol = '*';
	visited = false;
}

Location::Location(char c) {
	symbol = c;
}

int Location::visit(Player& p)
{
	if (visited == false) {
		visited = true;
		cout << "Visited" << endl;
	}
	return 0;
}

void Location::draw() {
	if (visited) cout << symbol;
	else cout << '.';
}
