#include "Lighthouse.h"

Lighthouse::Lighthouse() :Location('^')
{
	isOpen = false;
	numOfLock = 5;
	visited = false;
}

void Lighthouse::draw() {
	if (isOpen == true) cout << " ";
	else Location::draw();
}

void Lighthouse::Escape(Player p) {
	if (p.GetKeys() == numOfLock) cout << "The door is open. You won!" << endl;
	else cout << "You don't have enough key to unlock the door. Let's go find more keys!" << endl;
}

int Lighthouse::visit(Player& p)
{
	if (visited == false) {
		visited = true;
		cout << "You have arrived at the lighthouse." << endl;
		Escape(p);
		return 1;
	}
	return 0;
}