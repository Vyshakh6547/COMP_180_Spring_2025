#include "Player.h"

Player::Player() {
	name = "Khoa";
	age = 25;
	numOfKey = 0;
};

Player::Player(string n, int a, int k) {
	name = n;
	age = a;
	numOfKey = k;
};

void Player::SetName(string n) {
	name = n;
};

void Player::SetAge(int a) {
	if (a >= 18 && a <= 30) age = a;
	else cout << "Not a valid age!" << endl;
};

string Player::GetName() {
	return name;
};

int Player::GetAge() {
	return age;
};

void Player::SetKey(int k) {
	numOfKey = k;
};

void Player::FindKey() {
	numOfKey++;
};

void Player::PrintInfo() {
	cout << "Name: " << name << ", Age: " << age << ", Number of keys found: " << numOfKey << endl;
};

int Player::GetKeys() {
	return numOfKey;
}
