#include "Game.h"
#include "Crystal.h"
#include "Key.h"
#include "Lighthouse.h"

Game::Game() {
	rows = 0;
	cols = 0;
	playerRow = 0;
	playerCol = 0;
}

void Game::setUpGame() {
	rows = 8;
	cols = 8;
	playerRow = 4;
	playerCol = 4;
	world = new Location * *[rows];

	for (int i = 0; i < rows; i++) {
		world[i] = new Location*[cols];
		for (int j = 0; j < cols; j++) {
			world[i][j] = NULL;
		}
	}

	world[2][3] = new Crystal();
	world[4][5] = new Crystal();
	world[5][4] = new Crystal();

	world[5][5] = new Key();
	world[4][3] = new Key();
	world[3][4] = new Key();

	world[6][6] = new Lighthouse();

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			if (world[i][j] == NULL) world[i][j] = new Location();
			if (i == playerRow && j == playerCol) world[i][j] = new Location(' ');
		}
	}
}

void Game::drawGame() {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			if (i == playerRow && j == playerCol) cout << "P";
			else world[i][j]->draw();
		}
		cout << endl;
	}
}

void Game::playGame(Player p) {
	char input;

	setUpGame();

	do {
		drawGame();
		cout << "What direction do you want to move (u,d,l,r)?";
		cin >> input;

		switch (input)
		{
		case 'u':
			if (playerRow > 0) {
				playerRow--;
				world[playerRow][playerCol]->visit(p);
			}
			break;
		case 'd':
			if (playerRow < rows - 1) {
				playerRow++;
				world[playerRow][playerCol]->visit(p);
			}
			break;
		case 'l':
			if (playerCol > 0) {
				playerCol--;
				world[playerRow][playerCol]->visit(p);
			}
			break;
		case 'r':
			if (playerCol < cols - 1) {
				playerCol++;
				world[playerRow][playerCol]->visit(p);
			}
			break;
		default:
			break;
		}

	} while (input != 'q');

}

Game::~Game() {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			delete world[i][j];
		}
		delete[] world[i];
	}
	delete[] world;
}