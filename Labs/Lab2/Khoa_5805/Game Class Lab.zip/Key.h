#pragma once
#include "Location.h"
class Key :
    public Location
{
private:
    int numOfKey;
public:
    Key();
    void draw();
    int visit(Player&);
};

