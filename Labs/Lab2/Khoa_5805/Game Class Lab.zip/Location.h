#pragma once
#include "Player.h"

class Location
{
protected:
	char symbol;
	bool visited;
public:
	Location();
	Location(char);
	virtual void draw();
	virtual int visit(Player&);
};

