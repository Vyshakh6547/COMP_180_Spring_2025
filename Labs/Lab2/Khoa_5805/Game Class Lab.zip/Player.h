#pragma once
#include <iostream>

using namespace std;

class Player
{
private:
	string name;
	int age;
	int numOfKey;
public:
	Player();
	Player(string, int, int);
	void SetName(string);
	void SetAge(int);
	void FindKey();
	void SetKey(int);
	string GetName();
	int GetAge();
	void PrintInfo();
	int GetKeys();
};

