#include "Location.h"
#include "Crystal.h"
#include "Player.h"
#include <iostream>
using namespace std;
int main() {
	Player p;
	Location loc;
	Crystal crystal;

	cout << "Drawing initial states: " << endl;
	loc.draw();
	crystal.draw();
	cout << endl << "Visitng each location: " << endl;
	loc.visit(p);
	crystal.visit(p);
	cout << endl << "Redrawing Locations: " << endl;
	loc.draw();
	crystal.draw();

	return 0;

}