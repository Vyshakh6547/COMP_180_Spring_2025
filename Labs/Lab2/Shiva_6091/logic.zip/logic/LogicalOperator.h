#pragma once
#include <iostream>
#include <vector>
#include <string>
using namespace std;
class LogicalOperator {
public:
    int precedence(char op);
    bool applyOperator(char op, bool a1, bool a2);
    bool conjunc(bool a, bool b);
    bool disjunc(bool a, bool b);
    bool n(bool a);
    bool exor(bool a, bool b);
    bool condImp(bool a, bool b);
    bool biCond(bool a, bool b);
    bool evaluateExpression(const string& expression, const vector<bool>& values);
    void printTruthTable(int nV, const string& expression);
};
