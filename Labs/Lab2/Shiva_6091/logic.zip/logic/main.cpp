#include <iostream>
#include "LogicalOperator.h"
using namespace std;

int main() {
    int numVars;
    string expression;

    cout << "Enter the number of variables: ";
    cin >> numVars;
    cout << "Enter the logical expression: " << endl;
    cout << "You can use P,Q,R...only and |(or),&(and),^(xor),>(implication),~(negation),=(Biconditional)" << endl;
    cin >> expression;

    LogicalOperator l;
    l.printTruthTable(numVars, expression);

    return 0;
}