#include "LogicalOperator.h"
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
using namespace std;

bool LogicalOperator::conjunc(bool a, bool b) {
    return a && b;
}

bool LogicalOperator::disjunc(bool a, bool b) {
    return a || b;
}

bool LogicalOperator::n(bool a) {
    return !a;
}

bool LogicalOperator::exor(bool a, bool b) {
    return disjunc(conjunc(n(a), b), conjunc(a, n(b)));
}

bool LogicalOperator::condImp(bool a, bool b) {
    return disjunc(n(a), b);
}

bool LogicalOperator::biCond(bool a, bool b) {
    return !exor(a, b);
}
int LogicalOperator::precedence(char op) {
    if (op == '~') return 3;
    if (op == '&') return 2;
    if (op == '|') return 1;
    if (op == '^') return 1;
    if (op == '>') return 0;
    if (op == '=') return 0;
}


bool LogicalOperator::applyOperator(char op, bool a1, bool a2) {
    switch (op) {
    case '&': return a1 && a2;
    case '|': return a1 || a2;
    case '^': return a1 ^ a2;
    case '>': return (!a1 || a2);
    case '=': return (a1 == a2);
    }
    return false;
}
bool LogicalOperator::evaluateExpression(const string& expr, const vector<bool>& values) {
    vector<bool> evector;
    vector<char> opvector;

    for (int i = 0; i < expr.length(); i++) {
        char ch = expr[i];

        if (isalpha(ch)) {
            if (ch >= 'A' && ch < 'A' + values.size()) {
                evector.push_back(values[ch - 'A']);
            }
            else {
                cout << "Error: Variable " << ch << " is out of range." << endl;
                return false;
            }
        }

        else if (ch == '~') {
            if (!evector.empty()) {
                evector.back() = !evector.back();
            }
            else {
                cout << "Error: Invalid NOT operation on an empty expression" << endl;
                return false;
            }
        }

        else if (ch == '&' || ch == '|' || ch == '^' || ch == '>' || ch == '=') {
            while (!opvector.empty() && precedence(opvector.back()) >= precedence(ch)) {
                char op = opvector.back();
                opvector.pop_back();
                bool right = evector.back();
                evector.pop_back();
                bool left = evector.back();
                evector.pop_back();
                evector.push_back(applyOperator(op, left, right));
            }
            opvector.push_back(ch);
        }
    }

    while (!opvector.empty()) {
        char op = opvector.back(); opvector.pop_back();
        bool right = evector.back();
        evector.pop_back();
        bool left = evector.back();
        evector.pop_back();
        evector.push_back(applyOperator(op, left, right));
    }

    return evector.back();
}
void LogicalOperator::printTruthTable(int nV, const string& expression) {
    int numRows = pow(2, nV);
    vector<string> variables(nV);

    for (int i = 0; i < nV; ++i) {
        variables[i] = 'A' + i;
    }
    for (int i = 0; i < variables.size(); ++i) {
        cout << variables[i] << " ";
    }
    cout << expression << endl;

    for (int i = 0; i < numRows; ++i) {
        vector<bool> values(nV);
        for (int j = 0; j < nV; ++j) {
            values[j] = (i & (1 << (nV - j - 1))) != 0;
            cout << values[j] << " ";
        }

        bool result = evaluateExpression(expression, values);
        cout << result << endl;
    }
}