#include "Crystal.h"
Crystal::Crystal() : Location('$') {
	taken = false;
}
void Crystal::draw() {
	if (taken) cout << " ";
	else Location::draw();
}
int Crystal::visit(Player& p) {
	return Location::visit(p);
}