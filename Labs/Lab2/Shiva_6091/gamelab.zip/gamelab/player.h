#pragma once
#include <iostream>
#include <vector>
using namespace std;
class Player
{
private:
	string name;
	int id;
	string org;
public:
	Player();
	Player(string, int,string);
	void SetName(string);
	void SetId(int);
	void SetOrg(string);
	string GetName();
	int GetId();
	string GetOrg();
	void PrintInfo();
};
