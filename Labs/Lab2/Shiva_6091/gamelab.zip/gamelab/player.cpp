#include "Player.h"
Player::Player() {
	name = " ";
	id = 0;
	org = " ";
}
Player::Player(string n, int a,string o) {
	name = n;
	id = a;
	org = o;
}
void Player::SetName(string n) {
	name = n;
}
void Player::SetId(int a) {
	id = a;
}
void Player::SetOrg(string o) {
	org = o;
}


string Player::GetName() {
	return name;
}
int Player::GetId() {
	return id;

}
string Player::GetOrg() {
	return org;

}
void Player::PrintInfo() {
	cout << "PlayerName: " << name << "  Playerid: " << id << "player org: "<< org << endl;
}