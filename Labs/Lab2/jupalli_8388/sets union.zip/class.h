#pragma once
#include<vector>
#include<iostream>

using namespace std;


class Myset {
public:
	vector<int>items;
	void addItem(int);
	void removeitem(int);
	void uni(Myset);
	void diff(Myset);
	bool isItemOf(int);
	bool isSubset(Myset);
	int size();

};