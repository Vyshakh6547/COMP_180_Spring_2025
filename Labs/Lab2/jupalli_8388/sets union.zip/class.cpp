#include "class.h";

using namespace std;


void Myset::addItem(int a) {
	if (isItemOf(a)) {
		//cout << "items already exists" << endl;
	}
	else {
		items.push_back(a);
	}

}

void Myset::removeitem(int a) {
	for (int i = 0; i < items.size(); i++) {
		if (items[i] == a) {
			items.erase(items.begin() + i);
		}
	}
}
bool Myset::isItemOf(int a) {
	for (int i = 0; i < items.size(); i++) {
		if (items[i] == a) {
			//cout << "it belongs to the set" << endl;
			return true;
		}
	}

	return false;

}
bool Myset::isSubset(Myset set2) {
	for (int i = 0; i < items.size(); i++) {
		if (!set2.isItemOf(items[i])) {
			return false;
		}

	}
	return true;


}
int Myset::size() {
	return items.size();
}

void Myset::uni(Myset item4) {
	Myset result;
	for (int i = 0; i < items.size();i++) {
		result.addItem(items[i]);
   }
	for (int i = 0; i < item4.size();i++) {
		result.addItem(item4.items[i]);
	}

	for (int i = 0; i < result.size();i++) {
		cout << result.items[i] << endl;
	}
}

void Myset::diff(Myset item4) {
	Myset result1;
	for (int i = 0; i < items.size();i++) {
		if (!item4.isItemOf(items[i])) {
			result1.addItem(items[i]);
		}
	}

	for (int i = 0; i < result1.size();i++) {
		cout << result1.items[i] << endl;
	}
}
