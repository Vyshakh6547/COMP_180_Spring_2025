#include "Location.h"
#include "Crystal.h"
#include "Player.h"
#include "game.h"
#include <iostream>
using namespace std;
int main() {
	Player p;
	Location loc;
	Crystal crystal;
	game g;
	g.playGame();

	return 0;

}