#pragma once
#include "location.h"
#include "player.h"
#include "crystal.h"

class game
{
private:
	Location*** world;
	Player p;
	int rows;
	int cols;
	int playerCol;
	int playerRow;

   public:
	   game();
	   ~game();
	   void setUpGame();
	   void drawGame();
	   void playGame();




};

