#include "Location.h"

Location::Location(char s) {
	symbol = s;
	visited = false;
}
int Location::visit(Player& p) {
	visited = true;

	return 1;
}
void Location::draw() {
	if (visited) cout  << symbol;
	else cout << "*";
}