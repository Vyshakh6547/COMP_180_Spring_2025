#include "class.h";

using namespace std;


void Myset::addItem(int a) {
		if (isItemOf(a) == a) {
			cout << "items already exists" << endl;
		}
		else {
			items.push_back(a);
		}

}

void Myset::removeitem(int a) {
	for (int i = 0; i < items.size(); i++) {
		if (items[i] == a) {
			items.erase(items.begin() + i);
		}
	}
}
bool Myset::isItemOf(int a) {
	for (int i = 0; i < items.size(); i++) {
		if (items[i] == a) {
			cout << "it belongs to the set" << endl;
			return true;
		}
	}

	return false;

}
bool Myset::isSubset(Myset set2) {
	for (int i = 0; i < items.size(); i++) {
			if (!set2.isItemOf(items[i])) {
				return false;
			}
			
	}
	return true;


}
int Myset::size() {
	return items.size();
}
