#pragma once
#include<vector>
#include<iostream>

using namespace std;


class Myset {
public:
	vector<int>items;
	void addItem(int);
	void removeitem(int);
	vector<int> uni(vector<int>,vector<int>);
	bool isItemOf(int);
	bool isSubset(Myset);
	int size();

};