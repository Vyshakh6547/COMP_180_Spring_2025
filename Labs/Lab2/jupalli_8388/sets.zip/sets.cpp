#include <iostream>
#include<vector>
#include"class.h"

using namespace std;


int main() {

	Myset set, set2;
	set.addItem(1);
	set.addItem(2);
	set.addItem(3);
	set.addItem(4);
	set2.addItem(1);
	set2.addItem(2);
	set2.addItem(6);


	int b;
	cout << "1.add item" << endl;
	cout << "2.delet item" << endl;
	cout << "3.subset" << endl;
	cout << "4.size" << endl;
	cout << "5.is item" << endl;
	

	Myset set3;
	do {
		cout << "select the choice" << endl;
		cin >> b;
		switch (b) {
		case 1:
			int c;
			cout << "enter number" << endl;
			cin >> c;
			set.addItem(c);
			break;
		case 2:
			int d;
			cout << "enter number" << endl;
			cin >> d;
			set.removeitem(d);
			break;
		case 3:
			set3.items = { 1,2,3 };
			if (!set.isSubset(set3)) {
				cout << "not sub set" << endl;
			}
			else {
				cout << "subset" << endl;
			}
			break;

		case 4:
			cout << set.items.size() << endl;
			break;

		case 5:
			int e;
			cout << "enter number" << endl;
			cin >> e;
			set.isItemOf(e);
			break;


		}

	} while (b != 9);
	return 0;

}