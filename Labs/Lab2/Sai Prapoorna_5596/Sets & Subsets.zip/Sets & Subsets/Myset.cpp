#include "Myset.h"
#include <iostream>
#include <vector>
MySet::MySet() {
}
void MySet::addItem(int item) {
    if (!IsItemof(item)) {
        items.push_back(item);
    }
}
void MySet::removeItem(int item) {
    if (IsItemof(item)) {
        for (int i = 0; i < items.size(); i++) {
            if (items[i] == item) {
                items.erase(items.begin() + i);
                break;
            }
        }
    }
}
bool MySet::IsItemof(int item) {
    for (int i = 0; i < items.size(); i++) {
        if (items[i] == item) {
            return true;
        }
    }
    return false;
}
bool MySet::isSubset(MySet altSet) {
    for (int i = 0; i < altSet.items.size(); i++) {
        if (!IsItemof(altSet.items[i])) {
            return false;
        }
    }
    return true;
}
int MySet::size() {
    return items.size();
}
