#include<vector>
#include<iostream>
#include "Myset.h"
using namespace std;
int main() {
	vector<int> items;
	MySet set1;
	set1.addItem(1);
	set1.addItem(2);
	set1.addItem(3);
	MySet set2;
	set2.addItem(2);
	set2.addItem(3);
	cout << "Num of elements in set1 : " << endl;
	cout << set1.size() << endl;
	cout << "Num of elements in set2 : " << endl;
	cout << set2.size() << endl;
	bool isSubset = set1.isSubset(set2);
	cout << "Does set1 is a subset of set2 : " << endl;
	cout << isSubset << endl;
	set1.removeItem(3);
	cout << "size of set1 after updating: " << endl;
	cout << set1.size() << endl;
	return 0;
}