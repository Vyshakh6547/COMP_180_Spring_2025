#pragma once
#include <vector>
using namespace std;
class MySet {
private:
	vector<int> items;
public:
	MySet();
	void addItem(int item);
	void removeItem(int item);
	bool IsItemof(int item);
	bool isSubset(MySet);
	int size();
};

