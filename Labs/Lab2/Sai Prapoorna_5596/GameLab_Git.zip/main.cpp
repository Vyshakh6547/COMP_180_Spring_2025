#include <iostream>
#include "Location.h"
#include "Crystal.h"
#include "Player.h"
#include "Game.h"
using namespace std;
int main() {
	Player p;
	Crystal crystal;
	Location loc;
	Game g;
	g.playGame();
	return 0;

}
