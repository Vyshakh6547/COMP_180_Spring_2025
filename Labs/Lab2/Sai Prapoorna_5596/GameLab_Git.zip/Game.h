#pragma once
#include "Location.h"
#include "Player.h"
#include "Crystal.h"

class Game
{
private:
	Location*** world;
	Player p;
	int rows;
	int cols;
	int playerCol;
	int playerRow;
public:
	Game();
	~Game();
	void setUpGame();
	void drawGame();
	void playGame();
};
