#pragma once
#include "Player.h"
class Location
{
protected:
	char sysmbol;
	bool visited;
public:
	Location(char s = ' ');
	int visit(Player& p);
	void drawGame();
};

