#include "Player.h"
Player::Player() {
	playerName = " ";
	playerAge = 0;
}
Player::Player(string n, int a) {
	playerName = n;
}
void Player::SetplayerName(string n) {
	playerName = n;
}
string Player::Getplayername() {
	return playerName;
}
int Player::GetplayerAge() {
	return playerAge;
}
void Player::SetplayerAge(int n) {
	playerAge = n;
}
void Player::PrintInfo() {
	cout << "PlayerName: " << playerName << "PlayerAge: " << playerAge << endl;
}
void Player::Setgroup(string n) {
	group = n;
}
string Player::Getgroup() {
	return group;
}

