#include <iostream>
#include <vector>
#include <string>

using namespace std;

bool conjunction1(bool p, bool q) {
    return p && q;
}

bool disjunction1(bool p, bool q) {
    return p || q;
}

bool negation1(bool p) {
    return !p;
}

bool exclusive_or(bool p, bool q) {
    return conjunction1(disjunction1(p, q), negation1(conjunction1(p, q)));
}

bool conditional1(bool p, bool q) {
    return disjunction1(negation1(p), q);
}

bool bi_conditional1(bool p, bool q) {
    return conjunction1(conditional1(p, q), conditional1(q, p));
}

bool evaluate_expression(const string& expr, bool p, bool q, bool r) {
    for (int i = 0; i < expr.length(); ++i) {
        switch (expr[i]) {
        case 'a': return conjunction1(p, q);
        case 'n': return negation1(p);
        case 'o': return disjunction1(p, q);
        case 'x': return exclusive_or(p, q);
        case 'c': return conditional1(p, q);
        case 'b': return bi_conditional1(p, q);
        default: break;
        }
    }
    return false;
}

int main() {
    string expr1;
    string expr2;
    vector<bool> r1;
    vector<bool> r2;

    cout << "Enter a logical expression: ";
    cin >> expr1;
    cout << "Enter a logical expression: ";
    cin >> expr2;

    cout << "p\tq\tr\t" << expr1 << endl;

    for (int p = 0; p <= 1; ++p) {
        for (int q = 0; q <= 1; ++q) {
            for (int r = 0; r <= 1; ++r) {
                bool result1 = evaluate_expression(expr1, p, q, r);
                cout << (p ? "T" : "F") << "\t" << (q ? "T" : "F") << "\t" << (r ? "T" : "F") << "\t" << (result1 ? "T" : "F") << endl;
                r1.push_back(result1);
            }
        }
    }

    cout << "2nd expression" << endl;
    cout << "p\tq\tr\t" << expr2 << endl;

    for (int p = 0; p <= 1; ++p) {
        for (int q = 0; q <= 1; ++q) {
            for (int r = 0; r <= 1; ++r) {
                bool result2 = evaluate_expression(expr2, p, q, r);
                cout << (p ? "T" : "F") << "\t" << (q ? "T" : "F") << "\t" << (r ? "T" : "F") << "\t" << (result2 ? "T" : "F") << endl;
                r2.push_back(result2);
            }
        }
    }

    if (r1 == r2) {
        cout << "logical equivalent" << endl;
    }
    else {
        cout << "not logical equivalent" << endl;
    }

    return 0;
}